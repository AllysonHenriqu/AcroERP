
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Copiando estrutura do banco de dados para petshop
CREATE DATABASE IF NOT EXISTS `petshop` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `petshop`;

-- Copiando estrutura para tabela petshop.cadagendahorario
CREATE TABLE IF NOT EXISTS `cadagendahorario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `datagendamento` int(11) NOT NULL,
  `hora` int(11) NOT NULL,
  `nomecliente` int(11) NOT NULL,
  `procedimento` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_Cliente_fk` (`id_cliente`),
  CONSTRAINT `id_Cliente_fk2` FOREIGN KEY (`id_cliente`) REFERENCES `tbclientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.
-- Copiando estrutura para tabela petshop.tbaniaml
CREATE TABLE IF NOT EXISTS `tbaniaml` (
  `id_animal` int(11) NOT NULL AUTO_INCREMENT,
  `idcliente` varchar(50) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `raca` varchar(50) NOT NULL,
  PRIMARY KEY (`id_animal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.
-- Copiando estrutura para tabela petshop.tbanimal
CREATE TABLE IF NOT EXISTS `tbanimal` (
  `id_animal` int(10) unsigned DEFAULT NULL,
  `idcliente` varchar(50) DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `raca` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.
-- Copiando estrutura para tabela petshop.tbcadatendimento
CREATE TABLE IF NOT EXISTS `tbcadatendimento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `id_funcionario` int(11) NOT NULL,
  `nome_cliente` varchar(200) NOT NULL,
  `nome_animal` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_Cliente_fk` (`id_cliente`),
  KEY `id_funcionario_fk` (`id_funcionario`),
  CONSTRAINT `id_Cliente_fk` FOREIGN KEY (`id_cliente`) REFERENCES `tbclientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `id_funcionario_fk` FOREIGN KEY (`id_funcionario`) REFERENCES `tbfuncionario` (`ID`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Exportação de dados foi desmarcado.
-- Copiando estrutura para tabela petshop.tbclientes
CREATE TABLE IF NOT EXISTS `tbclientes` (
  `id_cliente` int(10) NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) DEFAULT NULL,
  `cpf` varchar(50) DEFAULT NULL,
  `telefone1` varchar(15) DEFAULT NULL,
  `telefone2` varchar(15) DEFAULT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `bairro` varchar(200) DEFAULT NULL,
  `endereco` varchar(200) DEFAULT NULL,
  `cep` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL,
  `confirmasenha` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Exportação de dados foi desmarcado.
-- Copiando estrutura para tabela petshop.tbfuncionario
CREATE TABLE IF NOT EXISTS `tbfuncionario` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) NOT NULL,
  `cpf` varchar(25) NOT NULL,
  `datnasc` varchar(15) NOT NULL,
  `telefone1` varchar(15) NOT NULL,
  `telefone2` varchar(15) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `bairro` varchar(200) NOT NULL,
  `endereço` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cargo` varchar(150) NOT NULL,
  `salario` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Exportação de dados foi desmarcado.
-- Copiando estrutura para tabela petshop.tbprodutos
CREATE TABLE IF NOT EXISTS `tbprodutos` (
  `Id_Produto` int(10) NOT NULL AUTO_INCREMENT,
  `codigodebarra` int(50) NOT NULL,
  `qtd` int(10) NOT NULL,
  `descricao` varchar(200) NOT NULL,
  `marca` varchar(100) NOT NULL,
  `valor` varchar(7) NOT NULL,
  `datvalidade` varchar(15) NOT NULL,
  `categoria` varchar(200) NOT NULL,
  PRIMARY KEY (`Id_Produto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Exportação de dados foi desmarcado.
-- Copiando estrutura para tabela petshop.tbvendas
CREATE TABLE IF NOT EXISTS `tbvendas` (
  `id_Vendas` int(10) NOT NULL AUTO_INCREMENT,
  `id_Cliente` int(10) NOT NULL,
  `id_Produto` int(10) NOT NULL,
  `Valor_Total` varchar(100) NOT NULL,
  `Data` varchar(15) NOT NULL,
  `Status` varchar(300) NOT NULL,
  PRIMARY KEY (`id_Vendas`),
  KEY `id_Cliente_fk3` (`id_Cliente`),
  KEY `id_produto_fk` (`id_Produto`),
  CONSTRAINT `id_Cliente_fk3` FOREIGN KEY (`id_Cliente`) REFERENCES `tbclientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `id_produto_fk` FOREIGN KEY (`id_Produto`) REFERENCES `tbprodutos` (`Id_Produto`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Exportação de dados foi desmarcado.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
tbanimaltbcadatendimento