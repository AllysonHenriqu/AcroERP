/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.acroerp;

import com.acroerp.beans.User;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author abhi
 */
public class CadAnimalServlet extends HttpServlet {

    Connection dbConnection = null;

    public void init() throws ServletException {
        super.init();
        connectDB();
    }
    void connectDB(){
        try {
            //STEP 2: Register JDBC driver
            Class.forName(Conexao.JDBC_DRIVER);

            //STEP 3: Open a connection
            System.out.println("Connecting to database...");
            dbConnection = DriverManager.getConnection(Conexao.DB_URL, Conexao.USER, Conexao.PASS);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        //HttpSession session = request.getSession();
        //session.setAttribute("error", "");
        RequestDispatcher dispatcher = request.getRequestDispatcher("cadanimalJSP.jsp");
        dispatcher.forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        System.out.print("In Post");
        String idcliente = request.getParameter("idcliente");
        String nome = request.getParameter("nomeanimal");
        String tipo = request.getParameter("tipo");
        String raca = request.getParameter("raca");
        
        
        HttpSession session = request.getSession();
        RequestDispatcher dispatcher = null;
        
        //verficação do campo se está com valor
        if (nome == null || tipo == null || nome.isEmpty() || tipo.isEmpty()) {
            response.sendRedirect(request.getRequestURI());
        }
        
        
       try {
           
           if (dbConnection == null) {
                connectDB();
            }
           
            String sql = "insert into tbanimal (idcliente,nome,tipo,raca)"
                + "values (?,?,?,?)";
            
               PreparedStatement stmt = dbConnection.prepareStatement(sql);
               
               stmt.setString(1, idcliente);
               stmt.setString(2, nome);
               stmt.setString(3, tipo);
               stmt.setString(4, raca);
               

            int row = stmt.executeUpdate();
            
            stmt.close();
            if (row > 0) {          
                System.out.print("OK");
                session.setAttribute("error", "Animal cadastrado com suacesso");
                response.sendRedirect("cadanimal");
            } else {
                session.setAttribute("error", "SQL Error!");
                dispatcher = request.getRequestDispatcher("cadanimal.jsp");
            }
        } catch (SQLException ex) {
            session.setAttribute("error", ex.getMessage());
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            dispatcher = request.getRequestDispatcher("cadanimal.jsp");
//            
        } catch (Exception ex) {;;
            session.setAttribute("error", ex.getMessage());
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            dispatcher = request.getRequestDispatcher("cadanimal.jsp");
        }
       
       if (dispatcher != null) {       
        dispatcher.forward(request, response);
       }
        
    }
    
    
}

        
    
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
//    @Override
//    public String getServletInfo() {
//        return "Short description";
//    }// </editor-fold>


