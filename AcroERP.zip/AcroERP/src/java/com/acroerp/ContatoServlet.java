/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.acroerp;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Allys
 */
public class ContatoServlet extends HttpServlet {
    
    
    Connection dbConnection = null;

    public void init() throws ServletException {
        super.init();
        connectDB();
    }
    void connectDB(){
        try {
            //STEP 2: Register JDBC driver
            Class.forName(Conexao.JDBC_DRIVER);

            //STEP 3: Open a connection
            System.out.println("Connecting to database...");
            dbConnection = DriverManager.getConnection(Conexao.DB_URL, Conexao.USER, Conexao.PASS);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        //HttpSession session = request.getSession();
        //session.setAttribute("error", "");
        RequestDispatcher dispatcher = request.getRequestDispatcher("contato.jsp");
        dispatcher.forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        
        System.out.print("In Post");
        String nome = request.getParameter("nome");
        String cpf = request.getParameter("cpf");
        String telefone1 = request.getParameter("telefone1");
        String telefone2 = request.getParameter("telefone2");
        String cidade = request.getParameter("cidade");
        String bairro = request.getParameter("bairro");
        String endereco = request.getParameter("endereco");
        String cep = request.getParameter("cep");
        String email = request.getParameter("email");
        String senha = request.getParameter("senha");
        String confirmasenha = request.getParameter("confirmasenha");
        
        HttpSession session = request.getSession();
        RequestDispatcher dispatcher = null;
        
        if (!senha.equals(confirmasenha)) {
            session.setAttribute("error", "Passwords should match!");
            dispatcher = request.getRequestDispatcher("cadclient.jsp");
            dispatcher.forward(request, response);
            return; 
        }
        
       try {
           
           if (dbConnection == null) {
                connectDB();
            }
           
            String sql = "insert into tbclientes (nome,cpf,telefone1,telefone2,cidade,bairro,endereco,cep,email,senha,confirmasenha) "
                + "values (?,?,?,?,?,?,?,?,?,?,?)";
            
               PreparedStatement stmt = dbConnection.prepareStatement(sql);
               
               stmt.setString(1, nome);
               stmt.setString(2, cpf);
               stmt.setString(3, telefone1);
                  stmt.setString(4, telefone2);
                   stmt.setString(5, cidade);
                    stmt.setString(6, bairro);
                     stmt.setString(7, endereco);
                      stmt.setString(8, cep);
                       stmt.setString(9, email);
                        stmt.setString(10, senha);
                         stmt.setString(11, confirmasenha);
               
            int row = stmt.executeUpdate();
            stmt.close();
            if (row > 0) {          
                System.out.print("OK");
                session.setAttribute("error", "Cliente Cadastrado com Sucesso");
                response.sendRedirect("cadcliente");
            } else {
                session.setAttribute("error", "SQL Error!");
                dispatcher = request.getRequestDispatcher("cadcliente.jsp");
            }
        } catch (SQLException ex) {
            session.setAttribute("error", ex.getMessage());
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            dispatcher = request.getRequestDispatcher("cadcliente.jsp");
//            
//        } catch (Exception ex) {;;
//            session.setAttribute("error", ex.getMessage());
//            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
//            dispatcher = request.getRequestDispatcher("cadcliente.jsp");
//        }
       
       if (dispatcher != null) {       
        dispatcher.forward(request, response);
       }
        
    }
    
    
}
}
    

